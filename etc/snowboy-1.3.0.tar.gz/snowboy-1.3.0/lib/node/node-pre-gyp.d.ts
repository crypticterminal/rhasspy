declare module "node-pre-gyp" {
  export function find(path:string):string;
}
